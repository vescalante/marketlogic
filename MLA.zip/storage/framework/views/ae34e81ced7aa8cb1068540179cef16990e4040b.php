<?php $__env->startSection('title', 'Position'); ?>


<?php $__env->startSection('header'); ?>
    <header class="masthead-reduced text-center text-white animated bounceInDown delay-1">
        <img src="/images/high/contactus.jpg" alt="">
        <div class="masthead-content">
            <div class="container-fluid">
                <!--<h1 class="masthead-heading mb-0"> <?php echo e($id); ?> </h1>-->
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-md-4 position-details-img animated fadeInright delay-3">
                    <img class="img-fluid position-thumbnail" src="/images/svg/ML_circle.svg">
                </div>
                <div class="col-md-8 position-details-txt animated fadeInLeft delay-2">
                    <div class="details-title">
                        <small>#<?php echo e($id); ?></small>
                        <h1>Creative Director</h1>
                        <h2>Everpost Ubicación de la empresa Guatemala, City, Guatemala, Guatemala</h2>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <h3>Nivel de Experiencia</h3>
                            <p>Intermedio</p>
                        </div>
                        <div class="col-md-6">
                            <h3>Tipo de Empleo</h3>
                            <p>Contrato por obra</p>
                        </div>
                        <div class="col-md-6">
                            <h3>Sector</h3>
                            <p>Marketing y publicidad</p>
                        </div>
                        <div class="col-md-6">
                            <h3>Tipo de Empleo</h3>
                            <p>Arte/Creatividad, Gestión</p>
                        </div>
                    </div>
                    <p>
                        Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam in consectetur neque.
                        Vestibulum ut faucibus sem. Duis nisi nulla, tincidunt non volutpat aliquam, feugiat at urna.
                        Etiam arcu arcu, commodo non erat vitae, dapibus aliquet sem. Fusce elit nibh, lobortis et mattis vel,
                        vehicula id nisi. Interdum et malesuada fames ac ante ipsum primis in faucibus. Ut eu risus scelerisque,
                        dapibus sapien sed, fringilla diam. Nunc aliquet orci quis placerat lacinia. Class aptent taciti sociosqu
                        ad litora torquent per conubia nostra, per inceptos himenaeos. Fusce at odio tellus.

                        Etiam non diam massa. Morbi quis rutrum dolor, nec scelerisque eros. Morbi eu justo est. Donec sagittis mi
                        at sagittis ultricies. Curabitur sodales augue eu eros posuere, eget accumsan est dictum. Praesent pulvinar
                        sem at felis varius, sagittis tincidunt neque pharetra. Morbi posuere nulla sodales vestibulum posuere.
                        Curabitur vitae malesuada felis. Praesent mollis felis mauris, hendrerit sodales neque luctus at.
                        Sed luctus, leo ut mollis semper, eros odio sollicitudin neque, non cursus orci libero et arcu. Morbi
                        porta diam vitae mi condimentum, porta dictum arcu ornare. In euismod scelerisque diam, ac finibus
                        ligula imperdiet non. Donec sed metus semper, suscipit dolor sit amet, commodo erat. Nullam gravida nibh a
                        aliquet tincidunt. Mauris iaculis sollicitudin sem, et dapibus dolor imperdiet a.
                    </p>
                    <h3>Interested candidates should posses:</h3>
                    <ul>
                        <li><i class="icofont-check-circled"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                        <li><i class="icofont-check-circled"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                        <li><i class="icofont-check-circled"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                        <li><i class="icofont-check-circled"></i> Lorem ipsum dolor sit amet, consectetur adipiscing elit.</li>
                    </ul>
                    <a href="#" data-featherlight="#apply-form" class="apply-puesto">Enviar solicitud</a>
                </div>
            </div>
        </div>
        <div class="lightbox" id="apply-form">
            <div class="row no-gutters apply-form">
                <div class="col-md-12">
                    <div class="form-title">
                        <h1>Solicitar Empleo</h1>
                    </div>
                    <div class="apply-form-container">
                        <form>
                            <div class="form-group">
                                <input type="text" class="form-control" id="nombre" placeholder="Nombre">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="apellido" placeholder="Apellido">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="ciudad" placeholder="Ciudad">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="telefono" placeholder="Télefono">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" id="email" placeholder="Email">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="salario" placeholder="Pretensión salarial">
                            </div>
                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="icofont-upload-alt"></i></div>
                                </div>
                                <input type="text" class="form-control" id="curriculum" placeholder="Subir Currículum">
                            </div>
                            <div class="text-right">
                                <button type="submit" class="btn apply-puesto pull-right">Enviar Solicitud</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mymarketlogic/marketlogic/resources/views/we-are/recruitment/position.blade.php ENDPATH**/ ?>