<?php $__env->startSection('title', 'Recruitment'); ?>


<?php $__env->startSection('header'); ?>
    <header class="masthead-reduced text-center text-white animated bounceInDown delay-1">
        <img src="/images/high/contactus.jpg" alt="">
        <div class="masthead-content">
            <div class="container-fluid">
                <h1 class="masthead-heading mb-0"> Recruitment</h1>
            </div>
        </div>
    </header>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container">
            <div class="row">
                <div class="col-lg-12 recruitment animated fadeInLeft delay-2">
                    <h3>¿QUIERES TRABAJAR CON NOSOTROS?</h3>
                    <h5>Encuentra tu siguiente empleo</h5>
                    <div style="display: flex; justify-content: center;">
                        <form class="form-search form-inline">
                            <label class="sr-only" for="cargo">Cargo</label>
                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="icofont-search-1"></i></div>
                                </div>
                                <select class="form-control search-query" id="cargo" name="cargo" placeholder="Busca por cargo">
                                    <option value="">- Buscar por cargo -</option>
                                    <option value="Jefe de Recursos Humanos">Jefe de Recursos Humanos</option>
                                    <option value="Jefe en puesto a aplicar">Jefe en puesto a aplicar</option>
                                    <option value="">Todos</option>
                                </select>
                            </div>

                            <label class="sr-only" for="ciudad">Ciudad</label>
                            <div class="input-group mb-2 mr-sm-2">
                                <div class="input-group-prepend">
                                    <div class="input-group-text"><i class="icofont-search-1"></i></div>
                                </div>
                                <select class="form-control search-query" id="ciudad" name="ciudad" placeholder="Busca por ciudad/país">
                                    <option value="">- Buscar por ciudad/país -</option>
                                    <option value="Guatemala">Guatemala</option>
                                    <option value="México">México</option>
                                    <option value="Colombia">Colombia</option>
                                    <option value="Miami">Miami</option>
                                    <option value="">Todos</option>
                                </select>
                            </div>

                            <button type="submit" class="btn btn-search mb-2">BUSCAR</button>
                        </form>
                    </div>
                </div>
                <div class="col-12 recruitment-box">
                    <div>
                        <h3>OFERTAS DE EMPLEO RECIENTES</h3>
                    </div>
                    <div class="row">

                            <div class="icon-box">
                                <img class="img-fluid" src="/images/svg/ML_circle.svg">
                                <div class="container-box">
                                    <h4 class="job-title">Jefe de Recursos Humanos</h4>
                                    <p class="job-description">Encargado de IT Ciudad de Guatemala</p>
                                    <div class="row content section-line">
                                        <div class="col-12">
                                            <a href="/weare/recruitment/position/1223445" class="ver-puesto">MÁS INFORMACIÓN <i class="icofont-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="icon-box">
                                <img class="img-fluid" src="/images/svg/ML_circle.svg">
                                <div class="container-box">
                                    <h4 class="job-title">Jefe en puesto a aplicar</h4>
                                    <p class="job-description">Encargado de IT Ciudad de México</p>
                                    <div class="row content section-line">
                                        <div class="col-12">
                                            <a href="/weare/recruitment/position/1323789" class="ver-puesto">MÁS INFORMACIÓN <i class="icofont-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="icon-box">
                                <img class="img-fluid" src="/images/svg/ML_circle.svg">
                                <div class="container-box">
                                    <h4 class="job-title">Jefe del puesto a aplicar</h4>
                                    <p class="job-description">Encargado de IT Ciudad de Colombia</p>
                                    <div class="row content section-line">
                                        <div class="col-12">
                                            <a href="/weare/recruitment/position/1423789" class="ver-puesto">MÁS INFORMACIÓN <i class="icofont-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="icon-box">
                                <img class="img-fluid" src="/images/svg/ML_circle.svg">
                                <div class="container-box">
                                    <h4 class="job-title">Administrador del puesto a aplicar</h4>
                                    <p class="job-description">Encargado de IT Ciudad de México</p>
                                    <div class="row content section-line">
                                        <div class="col-12">
                                            <a href="/weare/recruitment/position/1723789" class="ver-puesto">MÁS INFORMACIÓN <i class="icofont-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="icon-box">
                                <img class="img-fluid" src="/images/svg/ML_circle.svg">
                                <div class="container-box">
                                    <h4 class="job-title">Nombre del puesto a aplicar</h4>
                                    <p class="job-description">Encargado de IT Ciudad de Miami</p>
                                    <div class="row content section-line">
                                        <div class="col-12">
                                            <a href="/weare/recruitment/position/1623789" class="ver-puesto">MÁS INFORMACIÓN <i class="icofont-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>


                            <div class="icon-box">
                                <img class="img-fluid" src="/images/svg/ML_circle.svg">
                                <div class="container-box">
                                    <h4 class="job-title">Systems Developer</h4>
                                    <p class="job-description">Encargado de IT Ciudad de Guatemala</p>
                                    <div class="row content section-line">
                                        <div class="col-12">
                                            <a href="/weare/recruitment/position/1523789" class="ver-puesto">MÁS INFORMACIÓN <i class="icofont-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/mymarketlogic/marketlogic/resources/views/we-are/recruitment.blade.php ENDPATH**/ ?>